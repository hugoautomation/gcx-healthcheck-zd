(function() {
  const client = window.ZAFClient ? window.ZAFClient.init() : null;
  const HEALTHCHECK_TOKEN = 'uEzAH8oXKqkZL6IuiAQZFP8aas2ptfvx2BcYv3hr5EAwrFLysSIL5axpotPIpJst';
  
  // Register Handlebars helpers
  Handlebars.registerHelper('uppercase', function(str) {
      return str.toUpperCase();
  });

  Handlebars.registerHelper('formatDate', function(dateString) {
      const date = new Date(dateString);
      return date.toLocaleDateString() + ' ' + date.toLocaleTimeString();
  });

  if (!client) {
      console.error('ZAF Client could not be initialized');
      return;
  }

  client.invoke('resize', { width: '100%', height: '800px' });

  // Initialize domain
  client.context().then((context) => {
      const domain = `https://${context.account.subdomain}.zendesk.com`;
      document.getElementById('domain').value = domain;
  }).catch((error) => {
      console.error('Error getting context:', error);
  });

  // Compile templates once on load
  const resultsTemplate = Handlebars.compile(document.getElementById('results-template').innerHTML);
  const loadingTemplate = Handlebars.compile(document.getElementById('loading-template').innerHTML);
  const errorTemplate = Handlebars.compile(document.getElementById('error-template').innerHTML);

  document.getElementById('healthcheck-form').addEventListener('submit', (e) => {
      e.preventDefault();
      
      const domain = document.getElementById('domain').value;
      const email = document.getElementById('email').value;
      const token = document.getElementById('token').value;

      if (!email || !token) {
          alert('Please fill all the fields');
          return;
      }

      const apiEndpoint = 'https://app.configly.io/api/health-check/';

      // Show loading state
      document.getElementById('results').innerHTML = loadingTemplate();

      client.request({
          url: apiEndpoint,
          type: 'POST',
          headers: {
              'Content-Type': 'application/json',
              'X-API-Token': HEALTHCHECK_TOKEN
          },
          data: JSON.stringify({
              url: domain,
              email: email,
              api_token: token
          })
      }).then((response) => {
          // Prepare data for template
          const templateData = {
              ...response,
              error_count: response.issues.filter(issue => issue.type === 'error').length,
              warning_count: response.issues.filter(issue => issue.type === 'warning').length,
              has_issues: response.issues.length > 0
          };

          // Render template
          document.getElementById('results').innerHTML = resultsTemplate(templateData);

          // Adjust height based on content
          const resultsHeight = document.getElementById('results').scrollHeight;
          client.invoke('resize', { 
              width: '100%', 
              height: Math.max(800, resultsHeight + 100) 
          });

      }).catch((error) => {
          const errorData = {
              message: error.responseText ? JSON.parse(error.responseText).error : error.message
          };
          document.getElementById('results').innerHTML = errorTemplate(errorData);
          console.error('API Error:', error);
      });
  });
})();